module.exports = {
    api_url: process.env.REACT_APP_API_URL,
    token: "eyJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoxLCJleHAiOjE2NDIxMjI2MTZ9.O3p_xcjuRitnlYKRZB2sm6gpRprPAC23Dmdb5gV3KLs"
}